year_lst = []
for year in range(1900, 2021):
    year_lst.append(year)

print(year_lst)