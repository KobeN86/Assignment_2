var vg_1 = "visualisation.vg.json";
vegaEmbed("#radial_plot", vg_1).then(function(result) {
    // Access the Vega view instance (https://vega.github.io/vega/docs/api/view/) as result.view
}).catch(console.error);