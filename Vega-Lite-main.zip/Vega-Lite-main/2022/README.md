# Vega-lite examples

## 1. Intro to Vega-lite

### 1.1 A simple bar chart
https://fit3179.github.io/Vega-Lite/1_Intro/section1/

### 1.2 Dupliacte the european city example
https://fit3179.github.io/Vega-Lite/1_Intro/section2/

### 1.3 Stacked bar chart (covid-19)
https://fit3179.github.io/Vega-Lite/1_Intro/section3/


